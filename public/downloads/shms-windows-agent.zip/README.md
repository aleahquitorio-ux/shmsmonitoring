# SHMS Windows Monitoring Agent

This is a small command-line agent for the Server Health Monitoring System. It reports CPU usage, RAM usage, disk usage, uptime, hostname, OS, and CPU information only after the person at the computer explicitly types `YES` at the consent prompt.

## Requirements

- Windows 10/11 or another supported OS
- Node.js LTS from the official site: https://nodejs.org/en/download
- An SHMS account and a registered device
- Network access from this computer to the SHMS server

## Install dependencies

1. Extract this ZIP into a folder such as `C:\SHMS-Agent`.
2. Open PowerShell in that folder.
3. Run:

   ```powershell
   npm.cmd install
   ```

## Pair and run

1. Sign in to the SHMS website.
2. Register a device, or open an existing device's details, and copy its agent command. The pairing token is secret; do not share it.
3. Run the command in PowerShell from this folder. Example for a local SHMS server:

   ```powershell
   node agent.js --server http://localhost:3000 --token PASTE_YOUR_DEVICE_TOKEN_HERE
   ```

   Use the exact server URL shown by your SHMS website. If the server runs on a different computer, `localhost` is not the server; use the server's reachable LAN IP or public HTTPS URL instead.
4. Read the consent prompt and type `YES` only if you authorize this computer to send metrics.
5. The agent reports every 10 seconds. Press `Ctrl+C` to stop it.

## What is sent

CPU, memory, and storage utilization percentages; uptime; hostname; operating system; CPU model and core count; memory capacity; and the first detected/system disk capacity. Metrics are sent to the configured SHMS server with the device's pairing token.

## Troubleshooting

- `Could not contact monitoring server`: verify the server URL, network connection, and that the SHMS backend is running.
- `Invalid pairing token`: register the device again or copy its latest agent command from SHMS.
- `Monitoring consent has not been granted`: run the command again and type `YES` at the local consent prompt.
- Keep the pairing token private. Do not expose the SHMS server to the internet without HTTPS and appropriate production security configuration.
